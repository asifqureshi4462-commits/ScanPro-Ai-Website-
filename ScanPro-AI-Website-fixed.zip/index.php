<?php
declare(strict_types=1);

header('Location: frontend/index.php', true, 302);
exit;